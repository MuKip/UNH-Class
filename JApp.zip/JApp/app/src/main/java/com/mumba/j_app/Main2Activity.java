package com.mumba.j_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    private TextView mQuestion;
    private Button mAnswer1;
    private Button mAnswer2;
    private Button mAnswer3;
    private Button mAnswer4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        //referencing

        mQuestion = findViewById(R.id.activity_main_question_text);
        mAnswer1 = findViewById(R.id.activity_main_answer_btn1);
        mAnswer2 = findViewById(R.id.activity_main_answer_btn2);
        mAnswer3 = findViewById(R.id.activity_main_answer_btn3);
        mAnswer4 = findViewById(R.id.activity_main_answer_btn4);


    }
}
