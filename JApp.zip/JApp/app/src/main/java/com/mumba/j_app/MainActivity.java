package com.mumba.j_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {


    private TextView mGreetings;
    private EditText mNameInput;
    private Button mPlayButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Referencing

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGreetings = findViewById(R.id.activity_main_greeting_text);
        mNameInput = findViewById(R.id.activity_main_name_input);
        mPlayButton = findViewById(R.id.activity_main_play_btn);

        mPlayButton.setEnabled(false); // disabled the button
        mNameInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence S, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence S, int i, int i1, int i2) {
                mPlayButton.setEnabled(S.toString().length() != 0);

            }

            @Override
            public void afterTextChanged(Editable S) {

            }
        });
        mPlayButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent gameActivityIntent = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(gameActivityIntent);
            }
        });
    }
}
